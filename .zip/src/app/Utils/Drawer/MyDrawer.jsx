
import MyDrawerData from "./MyDrawerData";

export default function MiniDrawer() {
  return (
    <MyDrawerData/>
  );
}
