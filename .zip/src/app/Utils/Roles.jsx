
export const drawerWidth = 60;

